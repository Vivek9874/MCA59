<!DOCTYPE html>
<html>

<head>
    <title>FeeltheFeeling</title>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
        integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
        integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
        crossorigin="anonymous"></script>
</head>

<body>
    <nav class="navbar fixed-top navbar-expand-lg navbar-light " style="background-color: bisque;padding-top: 10px;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#tab1"><img src="logo4.1.png"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#tab1">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#tab2">Latest</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#tab3"><b>HELP!</b></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="prevart.html">Previous Articles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.html">About</a>
                    </li>
                </ul>
                <!-- Display user information if logged in -->
                <div class="navbar-text">
                    <?php
                    session_start();
                    require('db_connection.php');

                    // Check if the user is logged in
                    if (isset($_SESSION['user_id'])) {
                        // Fetch the user's information and display their username
                        $user_id = $_SESSION['user_id'];
                        $query = "SELECT username FROM users WHERE id = ?";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows === 1) {
                            $row = $result->fetch_assoc();
                            echo 'Welcome, ' . htmlspecialchars($row['username']) . '!';
                        } else {
                            echo 'Welcome, User!';
                        }

                        $stmt->close();
                    }
                    ?>
                </div>
            </div>
        </div>
    </nav>
    <div class="parallax1 h1 container-fluid" id="tab1"
        style="padding-bottom: 20px;"><h1 class="animate__animated  animate__slideInLeft"
            style=" text-align: center;font-family: 'Times New Roman', Times, serif;font-size:  80px;;"><br><br><br>Welcome
            to FeeltheFeeling</h1></div>
    <!--<h1 style="text-align: center; font-family: 'Times New Roman', Times, serif;font-size: 100px;">FeeltheFeeling</h1>-->

    <div class="container1 container-fluid">
        <p style="font-size: 25px;">Welcome to FeeltheFeeling, a website developed with the idea of getting people
            to talk about mental health. In the times that we live in, the idea about a person’s mental health <br>and
            well-being is often ignored,
            and we are trying to change it by putting the two most common domains of mental health i.e a blog and the
            other one being an actual mental health outlet, and putting them together.
            Here you can find most of what you’ll look out for on the internet when mental health is considered.</p>
    </div>
    <div class="parallax2" id="tab2">
        <div class="container">
            <div class="row">
                <div class=" col-lg-3 py-lg-1 px-lg-4 mr-lg-1 mt-5 mb-5 mx-auto ">
                    <div class="card text-black " style="background-color: #ffeecc;">
                        <img src="cory-GpK9rIM2EIA-unsplash.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h6 class="card-title"><b>Things people with anxiety want you to know</b></h6>
                            <p class="card-text">One might use the word 'anxious' quite often. However, there's a....<br></p>
                            <a href="art1.html" class="btn btn-primary" style="background-color: #f5a70a;">Read the
                                article</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 py-lg-1 px-lg-4 mr-lg-1 mt-5 mb-5 mx-auto">
                    <div class="card text-black" style="background-color: #ffeecc;">
                        <img src="huma-kabakci-oRk4Ep65tRc-unsplash.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Coming Soon</h5>
                            <p class="card-text">Stay tuned for more updates!<br><br><br></p>
                            <a href="Artcile1.php" class="btn btn-primary"
                                style="background-color: #f5a70a;">Go somewhere</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 py-lg-1 px-lg-4 mr-lg-1 mt-5 mb-5 mx-auto">
                    <div class="card text-black" style="background-color: #ffeecc;">
                        <img src="huma-kabakci-oRk4Ep65tRc-unsplash.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Coming Soon</h5>
                            <p class="card-text">Stay tuned for more updates!<br><br><br></p>
                            <a href="Artcile1.php" class="btn btn-primary"
                                style="background-color: #f5a70a;">Go somewhere</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container1 container-fluid">
        <p style="font-size: 25px;">As mentioned above, articles are one of two parts of FeeltheFeeling and this is
            where you’ll find them. <br>Do lookout for our upcoming newsletter to be the first one to know when any
            new articles are published.</p>
    </div>
    </div>

    <div class="parallax3 container-fluid" id="tab3"></div>
    <div class="container1 container-fluid">
        <p style="font-size: 25px ;">
            Here comes what we feel is the most important part of FeeltheFeeling. Firstly, if you ever feel a surge of
            negativity and depression, we recommend reaching out and talking to your parents, a friend, your school
            counselor, or a trusted adult.
            In some instances, you might not feel trustworthy to talk to anyone, or might want to be anonymous, this is
            where mental health and suicide prevention centers come in.
            We’ve compiled what we feel is one of the best outlets for your mental well-being. Feel free to reach out
            to any of these in case of difficult times to seek help, and just know that everything will be alright
            eventually.
            Click the “Know More” below to get to know the help center better.
        </p>
        <br>
        <p>
            <a href="HELP.html" class="a1 animate__animated animate__slideInDown"
                style="text-decoration: none;color: inherit ; font-size: larger;">Know More.<i
                    class="bi bi-caret-right-fill"></i></a>
        </p>
    </div>
    <hr style="border: 6px solid ; color: #f5a70a;">
    <br>
    <div class="container-fluid" style="padding: 0%;">
        <footer class="text-center text-lg-start" style="background-color: #ffc34d;">
            <div class="container d-flex justify-content-center py-5">
                <button type="button" class="btn btn-primary btn-lg btn-floating mx-2 border-0 shadow-lg"
                    style="background-color: #ffa600;">
                    <a></a><i class="bi bi-instagram"></i></a>
                </button>
                <button type="button" class="btn btn-primary btn-lg btn-floating mx-2 border-0 shadow-lg"
                    style="background-color: #ffa600;">
                    <i class="bi bi-google"></i>
                </button>
                <button type="button" class="btn btn-primary btn-lg btn-floating mx-2 border-0 shadow-lg"
                    style="background-color: #ffa600;">
                    <i class="bi bi-twitter"></i>
                </button>
                <button type="button" class="btn btn-primary btn-lg btn-floating mx-2 border-0 shadow-lg"
                    style="background-color: #ffa600;">
                    <i class="bi bi-linkedin"></i>
                </button>
            </div>
            <div class="text-center text-white p-3 " style="background-color: rgba(0, 0, 0, 0.2);">
                © 2020 Copyright:
                <a class="text-white" style="text-decoration: none;" href="index.htm#tab1">FeeltheFeeling</a>
            </div>
        </footer>
    </div>
</body>

</html>
